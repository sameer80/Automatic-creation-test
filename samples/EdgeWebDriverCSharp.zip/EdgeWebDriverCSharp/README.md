# Edge WebDriver (C#) — open URL with the same Edge profile

Hand-off sample for the C# Selenium team.

Opens **Microsoft Edge** with the **same local profile** the user already uses
(cookies, SSO login, corporate proxy, certificates, extensions).

---

## Why use a real profile?

A fresh Selenium profile often enables Secure DNS and ignores corporate PAC /
proxy settings. Internal UAT hostnames then fail with `ERR_NAME_NOT_RESOLVED`
even though the same URL opens when Edge is started manually.

Pointing WebDriver at the real profile inherits working network settings.

---

## Prerequisites

1. .NET 8 SDK  
2. Microsoft Edge installed  
3. **Close all Edge windows** before running (Task Manager → end `msedge.exe` if needed).  
   Edge locks the profile; WebDriver cannot attach while it is open.

---

## NuGet

```xml
<PackageReference Include="Selenium.WebDriver" Version="4.27.0" />
```

Selenium 4.6+ includes **Selenium Manager** — it downloads a matching `msedgedriver` automatically. No manual driver path needed.

---

## How to find your profile path

1. Open Edge manually.  
2. Go to `edge://version`.  
3. Copy **Profile path**, e.g.  
   `C:\Users\sameer.shaikh\AppData\Local\Microsoft\Edge\User Data\Default`  
4. Split it:
   - **user-data-dir** = `...\Edge\User Data`  
   - **profile-directory** = `Default` (or `Profile 1`, etc.)

---

## Run this sample

```powershell
cd samples\EdgeWebDriverCSharp
dotnet restore
dotnet run
```

Edit `Program.cs` constants:

| Constant            | Purpose                                      |
|---------------------|----------------------------------------------|
| `TargetUrl`         | URL to open                                  |
| `UserDataDir`       | Edge User Data folder (defaults to LOCALAPPDATA) |
| `ProfileDirectory`  | `Default` / `Profile 1` / …                  |
| `ProxyPacUrl`       | Optional PAC from `edge://net-internals/#proxy` |

---

## Minimal code (copy into your framework)

```csharp
using OpenQA.Selenium;
using OpenQA.Selenium.Edge;

var userDataDir = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
    "Microsoft", "Edge", "User Data");

var options = new EdgeOptions();
options.AddArgument($"--user-data-dir={userDataDir}");
options.AddArgument("--profile-directory=Default");
options.AddArgument("--remote-allow-origins=*");
options.AddArgument("--dns-over-https-mode=off");

using IWebDriver driver = new EdgeDriver(options);
driver.Navigate().GoToUrl("https://your-uat-url.example.com/");
```

Or use the helper:

```csharp
using var driver = EdgeDriverHelper.Create(
    url: "https://your-uat-url.example.com/",
    profileDirectory: "Default");
```

---

## Important notes for the team

1. **Close Edge first** — otherwise you get profile lock / session create errors.  
2. Do **not** run headless with a real interactive SSO profile unless you have validated it.  
3. Using a real profile mutates cookies/history on that machine — prefer a dedicated test machine or a **copied** profile folder for CI.  
4. For CI / shared agents, copy the profile once to a dedicated folder and set `user-data-dir` to that copy (never the live interactive profile on a build agent).  
5. Same flags exist in UTS Python: `automation/selenium_session.py` + `config/selenium.json` (`user_data_dir`, `profile_directory`).

---

## Equivalent UTS Python config

```json
{
  "browser": "edge",
  "user_data_dir": "C:\\Users\\<username>\\AppData\\Local\\Microsoft\\Edge\\User Data",
  "profile_directory": "Default",
  "disable_secure_dns": true,
  "proxy_pac_url": ""
}
```
