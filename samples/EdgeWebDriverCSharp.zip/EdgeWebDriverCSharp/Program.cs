using OpenQA.Selenium;
using OpenQA.Selenium.Edge;

namespace EdgeWebDriverCSharp;

/// <summary>
/// Opens Microsoft Edge with the SAME local user profile (cookies, SSO, proxy,
/// certificates, extensions) that the user already uses day-to-day.
///
/// Hand-off for the C# / Selenium team.
/// </summary>
internal static class Program
{
    // -------------------------------------------------------------------------
    // CONFIG — change these for your machine / environment
    // -------------------------------------------------------------------------

    /// <summary>URL to open after Edge starts.</summary>
    private const string TargetUrl =
        "https://uat-svb.uat.rosa-uat-de-aws-west1.zurich.com/applications/svb";

    /// <summary>
    /// Edge "User Data" folder (parent of Default / Profile 1 / …).
    /// Typical path:
    ///   C:\Users\&lt;username&gt;\AppData\Local\Microsoft\Edge\User Data
    /// Leave empty to use a fresh temporary profile instead.
    /// </summary>
    private static readonly string UserDataDir =
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Microsoft", "Edge", "User Data");

    /// <summary>
    /// Profile folder name inside User Data.
    /// Check edge://version → "Profile path" (last folder name).
    /// Usually "Default", sometimes "Profile 1", "Profile 2", …
    /// </summary>
    private const string ProfileDirectory = "Default";

    /// <summary>
    /// Optional corporate PAC URL (from edge://net-internals/#proxy on a working browser).
    /// Leave empty if the real profile already has proxy settings.
    /// </summary>
    private const string ProxyPacUrl = "";

    // -------------------------------------------------------------------------

    private static void Main()
    {
        Console.WriteLine("=== Edge WebDriver – open URL with real user profile ===");
        Console.WriteLine($"User data dir : {UserDataDir}");
        Console.WriteLine($"Profile       : {ProfileDirectory}");
        Console.WriteLine($"Target URL    : {TargetUrl}");
        Console.WriteLine();
        Console.WriteLine("IMPORTANT: Close ALL Edge windows (and msedge.exe in Task Manager) before running.");
        Console.WriteLine("           Edge locks the profile; WebDriver cannot use a locked profile.");
        Console.WriteLine();

        var options = EdgeDriverHelper.BuildOptions(UserDataDir, ProfileDirectory, ProxyPacUrl);

        // Selenium 4.6+ Selenium Manager finds / downloads matching msedgedriver automatically.
        using IWebDriver driver = new EdgeDriver(options);

        try
        {
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(90);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            driver.Manage().Window.Maximize();

            driver.Navigate().GoToUrl(TargetUrl);

            Console.WriteLine($"Opened: {driver.Url}");
            Console.WriteLine($"Title : {driver.Title}");
            Console.WriteLine();
            Console.WriteLine("Press Enter to quit and close the browser…");
            Console.ReadLine();
        }
        finally
        {
            driver.Quit();
        }
    }
}
