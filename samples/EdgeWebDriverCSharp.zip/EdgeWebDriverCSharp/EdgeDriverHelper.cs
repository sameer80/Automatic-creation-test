using OpenQA.Selenium;
using OpenQA.Selenium.Edge;

namespace EdgeWebDriverCSharp;

/// <summary>
/// Drop-in helper for the C# test framework.
/// Copy this class into your automation project and call <see cref="Create"/>.
/// </summary>
public static class EdgeDriverHelper
{
    /// <summary>
    /// Creates an Edge WebDriver session using the machine's real Edge profile
    /// (cookies, SSO, proxy, certs — same as opening Edge manually).
    /// </summary>
    /// <param name="url">Optional URL to navigate to after start.</param>
    /// <param name="userDataDir">
    /// Edge User Data folder. Default:
    /// %LOCALAPPDATA%\Microsoft\Edge\User Data
    /// </param>
    /// <param name="profileDirectory">Profile folder name, usually "Default".</param>
    /// <param name="proxyPacUrl">Optional PAC URL if profile proxy is not enough.</param>
    /// <returns>Caller must dispose / Quit the driver.</returns>
    public static IWebDriver Create(
        string? url = null,
        string? userDataDir = null,
        string profileDirectory = "Default",
        string? proxyPacUrl = null)
    {
        userDataDir ??= Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Microsoft", "Edge", "User Data");

        var options = BuildOptions(userDataDir, profileDirectory, proxyPacUrl);
        IWebDriver driver = new EdgeDriver(options);

        driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(90);
        driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);

        if (!string.IsNullOrWhiteSpace(url))
        {
            driver.Navigate().GoToUrl(url);
        }

        return driver;
    }

    /// <summary>
    /// Builds EdgeOptions so WebDriver reuses the same profile the user opens manually.
    /// Mirrors UTS automation/selenium_session.py network + profile flags.
    /// </summary>
    public static EdgeOptions BuildOptions(
        string userDataDir,
        string profileDirectory = "Default",
        string? proxyPacUrl = null)
    {
        var options = new EdgeOptions
        {
            PageLoadStrategy = PageLoadStrategy.Eager
        };

        // Stability / automation flags
        options.AddArgument("--window-size=1280,900");
        options.AddArgument("--disable-gpu");
        options.AddArgument("--no-sandbox");
        options.AddArgument("--disable-dev-shm-usage");
        options.AddArgument("--no-first-run");
        options.AddArgument("--remote-allow-origins=*");
        options.AddArgument("--disable-features=TranslateUI,AutomationControlled");

        // Corporate / UAT: fresh Selenium profiles often break DNS via Secure DNS (DoH).
        options.AddArgument("--disable-features=DnsOverHttps");
        options.AddArgument("--dns-over-https-mode=off");

        if (!string.IsNullOrWhiteSpace(proxyPacUrl))
        {
            options.AddArgument($"--proxy-pac-url={proxyPacUrl.Trim()}");
        }

        // *** Same profile the user already uses ***
        if (!string.IsNullOrWhiteSpace(userDataDir))
        {
            options.AddArgument($"--user-data-dir={userDataDir.Trim()}");
            options.AddArgument($"--profile-directory={profileDirectory.Trim()}");
        }

        options.AddAdditionalOption("excludeSwitches", new[] { "enable-automation", "enable-logging" });
        options.AddAdditionalOption("useAutomationExtension", false);

        return options;
    }
}
